package com.example.checklist.model;

public enum State {TODO, DONE, DOING}
