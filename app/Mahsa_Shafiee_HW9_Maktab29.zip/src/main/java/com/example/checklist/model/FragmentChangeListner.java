package com.example.checklist.model;

import androidx.fragment.app.Fragment;

public interface FragmentChangeListner {

    void replaceFragment(Fragment fragment);

}
