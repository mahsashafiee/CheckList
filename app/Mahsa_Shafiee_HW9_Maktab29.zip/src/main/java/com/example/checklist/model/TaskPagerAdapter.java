package com.example.checklist.model;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import com.example.checklist.R;
import com.example.checklist.controller.TaskListFragment;

public class TaskPagerAdapter extends FragmentStatePagerAdapter {

    private Context mContext;
    private User mUser;

    public TaskPagerAdapter(@NonNull FragmentManager fm, Context context, User user) {
        super(fm);
        mContext = context;
        mUser = user;
    }


    @NonNull
    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return TaskListFragment.newInstance(mUser, State.TODO);
        }

        if (position == 1) {
            return TaskListFragment.newInstance(mUser, State.DOING);
        }
        if (position == 2)
            return TaskListFragment.newInstance(mUser, State.DONE);

        return null;
    }


    @Override
    public int getCount() {
        return 3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return mContext.getString(R.string.category_TODO);
            case 1:
                return mContext.getString(R.string.category_DOING);
            case 2:
                return mContext.getString(R.string.category_DONE);
        }
        return null;
    }
}
