package com.example.checklist.controller;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.checklist.R;
import com.example.checklist.model.State;
import com.example.checklist.model.Task;
import com.example.checklist.model.TaskRecyclerViewAdapter;
import com.example.checklist.model.User;
import com.example.checklist.repository.Repository;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class TaskListFragment extends Fragment {

    private static final int REQUEST_CODE_TASK_DETAIL = 0;
    private static final String TAG_TASK_DETAIL = "taskDetail";
    private FloatingActionButton mAddTask;
    private RecyclerView mRecyclerView;
    private TaskRecyclerViewAdapter mAdapter;
    private List<Task> mTasks = new ArrayList<>();
    private User mUser;
    private State mState;

    private static final String TAG = "TaskListFragment";

    public static final String ARGS_USER_FROM_LOGIN = "args_user_from_login";
    public static final String ARGS_STATE_FROM_VIEW_PAGER = "args_state_from_view_pager";
    private Repository mRepository;

    public static TaskListFragment newInstance(User user, State state) {

        Bundle args = new Bundle();

        TaskListFragment fragment = new TaskListFragment();
        args.putSerializable(ARGS_USER_FROM_LOGIN, user);
        args.putSerializable(ARGS_STATE_FROM_VIEW_PAGER, state);
        fragment.setArguments(args);
        return fragment;
    }


    public TaskListFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: called");

        mUser = ((User) getArguments().getSerializable(ARGS_USER_FROM_LOGIN));
        mState = (State) getArguments().getSerializable(ARGS_STATE_FROM_VIEW_PAGER);
        mRepository = Repository.getInstance(mUser);
        mTasks = mRepository.getTasks(mUser.getID(), mState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_task_list, container, false);
        Log.d(TAG, "onCreateView: called");
        initRecyclerView(view);

        mAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Task task = new Task();
                task.setState(mState);
                mRepository.addTask(mUser.getID(), task);
                TaskDetailFragment taskDetailFragment = TaskDetailFragment.newInstance(mUser.getID(), task.getID());
                taskDetailFragment.setTargetFragment(TaskListFragment.this, REQUEST_CODE_TASK_DETAIL);
                taskDetailFragment.show(getFragmentManager(), TAG_TASK_DETAIL);
            }
        });

        return view;
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: called");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: called");
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: called");
    }

    private void initRecyclerView(View view) {
        mAddTask = view.findViewById(R.id.addTask);
        mRecyclerView = view.findViewById(R.id.task_list_recyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mAdapter = new TaskRecyclerViewAdapter(getActivity(),mTasks, mUser.getID());
        mRecyclerView.setAdapter(mAdapter);
    }

}
